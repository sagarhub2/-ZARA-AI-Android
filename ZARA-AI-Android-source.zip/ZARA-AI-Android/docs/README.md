# Project documentation

- [Voice architecture research](architecture/voice-architecture-research.md): background service behavior, interaction states, and Android platform constraints.
- [Voice issue recordings](diagnostics/voice-videos/README.md): user-provided recordings associated with reported voice and automation issues.

Keep durable project guidance here. Generated APKs, Gradle caches, and local machine configuration belong outside source documentation and are ignored by Git.


## MANSI AI customization note

This starter changes the visible app label and selected HUD labels to MANSI AI while intentionally preserving internal Kotlin package/class names and the existing release-verification logic. It is not yet a finished MANSI AI redesign or a verified APK.
