# ZARA AI Android

Separate ZARA AI Android project derived from the provided MANSI/JARVIS-based source archive.

- Android application ID / namespace: `com.zara.ai`
- App label: `ZARA AI`
- Theme accent direction: neon pink / purple
- Original MANSI source is not modified by this project copy.

## Build

Open this folder in Android Studio and sync Gradle, or run `./gradlew assembleDebug`.
The release build requires configured signing credentials and release security properties.

## Important

Changing the app identity and theme does not prove that every voice, Gemini, floating overlay, or phone-automation feature works on every device. Those features require device-level tests and any relevant API keys/Android permissions.
