package com.zara.ai.ui.settings

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.zara.ai.R

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        com.zara.ai.util.ThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        findViewById<android.view.View>(R.id.settingsContainer)?.let {
            com.zara.ai.util.ThemeManager.applyDynamicBackground(it)
        }
    }
}
